/**
 * 
 */
package com.apple.movie.dto;

/**
 * @author ronithrajgund
 *
 */
public class CustomersDTO {

	private Integer customerId;
	private String customerFirstName;
	private String customerLastName;
	private Double customerAverageRating;
	private Double averageRating;

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getCustomerFirstName() {
		return customerFirstName;
	}

	public void setCustomerFirstName(String customerFirstName) {
		this.customerFirstName = customerFirstName;
	}

	public String getCustomerLastName() {
		return customerLastName;
	}

	public void setCustomerLastName(String customerLastName) {
		this.customerLastName = customerLastName;
	}

	public Double getCustomerAverageRating() {
		return customerAverageRating;
	}

	public void setCustomerAverageRating(Double customerAverageRating) {
		this.customerAverageRating = customerAverageRating;
	}

	public Double getAverageRating() {
		return averageRating;
	}

	public void setAverageRating(Double averageRating) {
		this.averageRating = averageRating;
	}

}
