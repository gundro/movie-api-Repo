/**
 * 
 */
package com.apple.movie.controller;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.apple.movie.dto.EmployeeDTO;

/**
 * @author ronithrajgund
 *
 */
@RestController
public class EmployeeController {
	
private static Logger log = LoggerFactory.getLogger(EmployeeController.class);
	
	@GetMapping(value = "/api/allEmployees")
	 public List<EmployeeDTO> getAllEmployees() {
		EmployeeDTO e1 = new EmployeeDTO("Ronith", 34);
		EmployeeDTO e2 = new EmployeeDTO("Souradeep", 30);
		EmployeeDTO e3 = new EmployeeDTO("Dipto", 31);
		EmployeeDTO e4 = new EmployeeDTO("Lakshmi", 10);
		EmployeeDTO e5 = new EmployeeDTO("Bhawna", 9);
		EmployeeDTO e6 = new EmployeeDTO("Ralph", 11);
 
        List<EmployeeDTO> employees = new ArrayList<EmployeeDTO>();
        employees.add(e2);
        employees.add(e3);
        employees.add(e1);
        employees.add(e4);
        employees.add(e5);
        employees.add(e6);
        
     // UnSorted List
        log.info("UNSORTED LIST====>");
        System.out.println(employees);
        
      //Sorting on multiple fields; Group by.
        Comparator<EmployeeDTO> groupByComparator = Comparator.comparing(EmployeeDTO::getAge).thenComparing(EmployeeDTO::getName);
        employees.sort(groupByComparator);
        return employees.stream().filter(obj -> obj.getAge()>=10).collect(Collectors.toList());
        
		
		
	}

}
