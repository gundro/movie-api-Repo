/**
 * 
 */
package com.apple.movie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author ronithrajgund
 *
 */
@SpringBootApplication
public class MovieApplication {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(MovieApplication.class, args);

	}

}
