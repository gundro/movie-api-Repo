/**
 * 
 */
package com.apple.movie.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.apple.movie.dto.MovieDTO;

/**
 * @author ronithrajgund
 *
 */
public class MovieRowMapper implements RowMapper<MovieDTO>  {

	@Override
	public MovieDTO mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		MovieDTO dto = new MovieDTO();
		dto.setCustFirstName(rs.getString("custFirstName"));
		dto.setCustLastName(rs.getString("custLastName"));
		dto.setMovieName(rs.getString("movieName"));
		dto.setMovieRating(rs.getDouble("rating"));
		dto.setMovieId(rs.getInt("movieId"));
		dto.setCustomerID(rs.getInt("custId"));
		return dto;
	}
	
	

}
