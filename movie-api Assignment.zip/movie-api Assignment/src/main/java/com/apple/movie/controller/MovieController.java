/**
 * 
 */
package com.apple.movie.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.apple.movie.dto.CustomersDTO;
import com.apple.movie.dto.MovieDTO;
import com.apple.movie.service.MovieService;

/**
 * @author ronithrajgund
 *
 */

@RestController
public class MovieController {

	private static Logger log = LoggerFactory.getLogger(MovieController.class);

	@Autowired
	private MovieService service;

	@PostMapping(value = "/api/rest/customer/{customerId}/rate/{rating}")
	public String insertMovies(@PathVariable("customerId") Integer customerId, @PathVariable("rating") Double rating,
			@RequestBody final MovieDTO movie) {
		if (service.insertMovie(customerId, rating, movie)) {
			return "SUCCESS";
		}
		return "FAIL";

	}

	@GetMapping(value = "/api/rest/movies")
	public List<MovieDTO> getAllMovies() {
		return service.getAllMovieDetails();

	}

	@GetMapping(value = "/api/rest/highestRatedMovieOnAvg")
	public String highestRatedMovieOnAvg() {
		return service.gethighestRatedMovieOnAvg();
	}

	@GetMapping(value = "/api/rest/customerHighestAverageRating")
	public CustomersDTO customerHighestAverageRating() {
		return service.customerHighestAverageRating();
	}

}
