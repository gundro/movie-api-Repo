/**
 * 
 */
package com.apple.movie.service;

import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.apple.movie.dto.CustomersDTO;
import com.apple.movie.dto.MovieDTO;
import com.apple.movie.dto.RatingDTO;
import com.apple.movie.mapper.MovieRowMapper;

/**
 * @author ronithrajgund
 *
 */
@Repository
public class MovieService {
	private static Logger log = LoggerFactory.getLogger(MovieService.class);

	private final JdbcTemplate jdbcTemplate;
	final String INSERT_QUERY = "INSERT INTO movie (custId,movieId,movieName,custFirstName,custLastName,rating) VALUES(?,?,?,?,?,?);";

	@Autowired
	public MovieService(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public List<MovieDTO> getAllMovieDetails() {
		String query = "SELECT * from movie";
		RowMapper<MovieDTO> rowMapper = new MovieRowMapper();
		List<MovieDTO> list = jdbcTemplate.query(query, rowMapper);
		return list;
	}

	public boolean insertMovie(Integer customerId, Double rating, MovieDTO movie) {
		int saveVal = jdbcTemplate.update(INSERT_QUERY, customerId, movie.getMovieId(), movie.getMovieName(),
				movie.getCustFirstName(), movie.getCustLastName(), rating);
		if (saveVal != 0) {
			return true;
		}
		return false;

	}

	public String gethighestRatedMovieOnAvg() {
		List<MovieDTO> movieDtlList = getAllMovieDetails();

		HashMap<String, RatingDTO> ratings = new HashMap<>();
		HashMap<String, Double> maxAvgRtngMap = new HashMap<>();

		movieDtlList.forEach((movieDto) -> {
			if (!ratings.containsKey(movieDto.getMovieName())) {
				RatingDTO rs = new RatingDTO();
				rs.addRating(movieDto.getMovieRating());
				ratings.put(movieDto.getMovieName(), rs);
			} else {
				RatingDTO rs = ratings.get(movieDto.getMovieName());
				rs.addRating(movieDto.getMovieRating());
			}
		});
		// Iterating through the HashMap to get the average for each movie
		ratings.forEach((k, v) -> {
			RatingDTO rs = ratings.get(k);
			Double avg = rs.getSumRatings() / rs.getNumRatings();
			maxAvgRtngMap.put(k, avg);
			log.info("%s: %d reviews, average of %.1f/5\n", k, rs.getNumRatings(), avg);
		});
		Map<String, Double> sorted = maxAvgRtngMap.entrySet().stream()
				.sorted(Collections.reverseOrder(Map.Entry.comparingByValue()))
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e2, LinkedHashMap::new));
		String firstKey = sorted.keySet().iterator().next();
		log.info("First Key ->" + firstKey);
		Double firstValAvgRating = sorted.get(firstKey);
		log.info("First Val Avg Rating ->" + firstValAvgRating);
		return firstKey + " : " + firstValAvgRating;
	}

	public CustomersDTO customerHighestAverageRating() {
		CustomersDTO respObj = new CustomersDTO();
		List<MovieDTO> movieDtlList = getAllMovieDetails();
		HashMap<Integer, RatingDTO> custRatings = new HashMap<>();
		//HashMap<String, RatingDTO> movieRatings = new HashMap<>();
		HashMap<Integer, Double> custMaxAvgRtngMap = new HashMap<>();
		//HashMap<String, Double> movieMaxAvgRtngMap = new HashMap<>();

		Double avgCustOverAllRating = movieDtlList.stream().map(x -> x.getMovieRating())
				.collect(Collectors.summingDouble(Double::doubleValue)) / movieDtlList.size();

		movieDtlList.forEach((movieDto) -> {
			// Customer Avg Rating Calculation
			if (!custRatings.containsKey(movieDto.getCustomerID())) {
				RatingDTO rs = new RatingDTO();
				rs.addRating(movieDto.getMovieRating());
				custRatings.put(movieDto.getCustomerID(), rs);
			} else {
				RatingDTO rs = custRatings.get(movieDto.getCustomerID());
				rs.addRating(movieDto.getMovieRating());
			}
			// Movie Avg rating Calculation
			/**
			 * if (!movieRatings.containsKey(movieDto.getMovieName())) { RatingDTO rs = new
			 * RatingDTO(); rs.addRating(movieDto.getMovieRating());
			 * movieRatings.put(movieDto.getMovieName(), rs); } else { RatingDTO rs =
			 * movieRatings.get(movieDto.getMovieName());
			 * rs.addRating(movieDto.getMovieRating()); }
			 **/

		});
		// Iterating through the HashMap to get the average Rating for each customer
		custRatings.forEach((k, v) -> {
			RatingDTO rs = custRatings.get(k);
			Double avg = rs.getSumRatings() / rs.getNumRatings();
			custMaxAvgRtngMap.put(k, avg);
			log.info(String.format("Customer ID:%s , No Of Reviews:%s , custAvgRating:%s", k, rs.getNumRatings(), avg));
		});

		Map<Integer, Double> sorted = custMaxAvgRtngMap.entrySet().stream()
				.sorted(Collections.reverseOrder(Map.Entry.comparingByValue()))
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue, (e1, e2) -> e2, LinkedHashMap::new));
		Integer custIDWithMaxAvgRating = sorted.keySet().iterator().next();
		log.info("Customer ID  ->" + custIDWithMaxAvgRating);
		Double maxAvgRating = sorted.get(custIDWithMaxAvgRating);
		log.info("With highest Customer Avg Rating :" + maxAvgRating);
		List<MovieDTO> cust = getMovieDetailsWithMaxCustAvgRating(custIDWithMaxAvgRating);

		// Iterating through the HashMap to get the average Rating for each Movie marked
		// by customers
		/**
		 * movieRatings.forEach((k, v) -> { RatingDTO rs = movieRatings.get(k); Double
		 * avg = rs.getSumRatings() / rs.getNumRatings(); movieMaxAvgRtngMap.put(k,
		 * avg); log.info(String.format("MovieName:%s , No Of Reviews:%s ,
		 * movieAvgRating:%s", k, rs.getNumRatings(), avg)); });
		 **/
		respObj.setCustomerFirstName(cust.get(0).getCustFirstName());
		respObj.setCustomerLastName(cust.get(0).getCustLastName());
		respObj.setCustomerAverageRating(maxAvgRating);
		respObj.setCustomerId(custIDWithMaxAvgRating);
		respObj.setAverageRating(avgCustOverAllRating);
		return respObj;
	}

	private List<MovieDTO> getMovieDetailsWithMaxCustAvgRating(Integer custIDWithMaxAvgRating) {
		String query = "SELECT * from movie where custId =?";
		RowMapper<MovieDTO> rowMapper = new MovieRowMapper();
		List<MovieDTO> list = jdbcTemplate.query(query, rowMapper, custIDWithMaxAvgRating);
		return list;
	}

}
