/**
 * 
 */
package com.apple.movie.dto;

/**
 * @author ronithrajgund
 *
 */
public class MovieDTO {

	private Integer movieId;
	private String movieName;
	private Double movieRating;
	private Integer customerID;
	private String custFirstName;
	private String custLastName;
	
	private Double averageMovieRating;

	public Integer getMovieId() {
		return movieId;
	}

	public void setMovieId(Integer movieId) {
		this.movieId = movieId;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public Double getMovieRating() {
		return movieRating;
	}

	public void setMovieRating(Double movieRating) {
		this.movieRating = movieRating;
	}

	public Integer getCustomerID() {
		return customerID;
	}

	public void setCustomerID(Integer customerID) {
		this.customerID = customerID;
	}

	public String getCustFirstName() {
		return custFirstName;
	}

	public void setCustFirstName(String custFirstName) {
		this.custFirstName = custFirstName;
	}

	public String getCustLastName() {
		return custLastName;
	}

	public void setCustLastName(String custLastName) {
		this.custLastName = custLastName;
	}

	public Double getAverageMovieRating() {
		return averageMovieRating;
	}

	public void setAverageMovieRating(Double averageMovieRating) {
		this.averageMovieRating = averageMovieRating;
	}

}
