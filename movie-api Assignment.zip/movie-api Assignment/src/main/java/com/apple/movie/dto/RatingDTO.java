/**
 * 
 */
package com.apple.movie.dto;

/**
 * @author ronithrajgund
 *
 */
public class RatingDTO {

	private int numRatings;
	private Double sumRatings;
	
	public RatingDTO()
    {
        numRatings = 0;
        sumRatings = 0.0;
    }

	public int getNumRatings() {
		return numRatings;
	}

	public void setNumRatings(int numRatings) {
		this.numRatings = numRatings;
	}

	public Double getSumRatings() {
		return sumRatings;
	}

	public void setSumRatings(Double sumRatings) {
		this.sumRatings = sumRatings;
	}

	
	public void addRating(Double rating)
    {
        numRatings++;
        sumRatings += rating;
    }
}
