INSERT INTO movie (custId,movieId,movieName,custFirstName,custLastName,rating) VALUES(2,1,'znmd', 'Ronith','Gund',4.5);
INSERT INTO movie (custId,movieId,movieName,custFirstName,custLastName,rating) VALUES(2,7,'Kung Fu Panda', 'Ronith','Gund',4.6);
INSERT INTO movie (custId,movieId,movieName,custFirstName,custLastName,rating) VALUES(3,1,'znmd', 'Bhawna','Khattar',3.6);
INSERT INTO movie (custId,movieId,movieName,custFirstName,custLastName,rating) VALUES(3,2,'DDLJ', 'Dhrubo','Mukhuty',3.8);
INSERT INTO movie (custId,movieId,movieName,custFirstName,custLastName,rating) VALUES(1,2,'DDLJ', 'Kailash','Kher',4.1);
INSERT INTO movie (custId,movieId,movieName,custFirstName,custLastName,rating) VALUES(1,3,'KNPH', 'Meghna','Manglani',4.3);
INSERT INTO movie (custId,movieId,movieName,custFirstName,custLastName,rating) VALUES(5,3,'THE BOURNE ULTIMATUM', 'Sourav','Dutta',3.5);
