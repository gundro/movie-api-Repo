CREATE TABLE movie (
  custId bigint(20) NOT NULL,
  movieId bigint(20) NOT NULL,
  movieName varchar(100) NOT NULL,
  custFirstName varchar(100) NOT NULL,
  custLastName varchar(100) NOT NULL,
  rating DECIMAL(6,5) NOT NULL,
  CONSTRAINT PK_Movie PRIMARY KEY (custId,movieId) 
);